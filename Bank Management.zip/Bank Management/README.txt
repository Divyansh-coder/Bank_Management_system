Directly Run the application
 
password to login = 1234
 Thank you. 